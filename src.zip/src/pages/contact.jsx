import React from 'react'
import Navbar from '../components/NavBar';
const Contact=()=> {
  return (
    <>
      <header>
      <Navbar />
      </header>
      <h1 className='text-3xl font-bold mb-6'>Contact</h1>
    </>
  )
}

export default Contact